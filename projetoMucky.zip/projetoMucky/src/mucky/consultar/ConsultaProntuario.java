package mucky.consultar;

import mucky.cadastrar.CadastroProntuario;
import mucky.dao.ProntuarioDAO;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.util.List;
import mucky.FormCadastrar;
import mucky.FormCadastrar;
import mucky.GeradorPdf;
import mucky.GeradorPdf;

/**
 *
 * @author deborah
 */
public class ConsultaProntuario extends javax.swing.JFrame {

   
   public ConsultaProntuario() {
        initComponents();
        tblProntuario.setModel(new javax.swing.table.DefaultTableModel(
        new Object [][] {},
        new String [] {
            "ID", "Nome", "Enfermidade", "Tratamento", "Profissional", "Data de inicio"
        }
    ) {
        Class[] types = new Class [] {
            java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
        };

        public Class getColumnClass(int columnIndex) {
            return types [columnIndex];
        }
    });
    
   
    tblProntuario.getColumnModel().getColumn(0).setMinWidth(0);
    tblProntuario.getColumnModel().getColumn(0).setMaxWidth(0);
    tblProntuario.getColumnModel().getColumn(0).setWidth(0);
        setLocationRelativeTo(null);
        setExtendedState(javax.swing.JFrame.NORMAL);
        setAlwaysOnTop(true);
        toFront();
        requestFocus();
        
// Desativa o "sempre no topo" logo em seguida para que o usuário possa minimizar se quiser depois
        java.awt.EventQueue.invokeLater(() -> setAlwaysOnTop(false));
        carregarTabelaProntuarios(""); // Passa vazio para carregar todos ao abrir a tela
        
    }
    
    // Sobrecarga: carregar sem parâmetro busca todos
    private void carregarTabelaProntuarios() {
        carregarTabelaProntuarios("");
    }

    // Carrega e filtra os prontuários cadastrados na JTable
    private void carregarTabelaProntuarios(String filtro) {
        ProntuarioDAO dao = new ProntuarioDAO();
        List<ProntuarioDAO.ProntuarioDTO> lista = dao.listarProntuarios(filtro);
        
        DefaultTableModel model = (DefaultTableModel) tblProntuario.getModel();
        model.setRowCount(0); // Limpa a tabela

        for (ProntuarioDAO.ProntuarioDTO p : lista) {
            model.addRow(new Object[]{
                p.getId(),
                p.getNomePaciente(),
                p.getEnfermidade(),
                p.getNomeTratamento(),
                p.getNomeFuncionario(),
                p.getDataAtendimento()
            });
        }
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblTItulo = new javax.swing.JLabel();
        lblNome = new javax.swing.JLabel();
        txtNome = new javax.swing.JTextField();
        btnBuscar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblProntuario = new javax.swing.JTable();
        btnEditar = new javax.swing.JButton();
        btnExcluir = new javax.swing.JButton();
        btnVoltar = new javax.swing.JButton();
        btnEmitirPdf = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Projeto Mucky");

        lblTItulo.setFont(new java.awt.Font("Quicksand", 1, 18)); // NOI18N
        lblTItulo.setText("Consulta Cadastro Prontuário");

        lblNome.setFont(new java.awt.Font("Quicksand", 1, 15)); // NOI18N
        lblNome.setText("Pesquisa por nome");

        btnBuscar.setFont(new java.awt.Font("Quicksand", 0, 15)); // NOI18N
        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        tblProntuario.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Nome", "Enfermidade", "Tratamento", "Profissional", "Data de inicio"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Object.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tblProntuario);

        btnEditar.setFont(new java.awt.Font("Quicksand", 0, 15)); // NOI18N
        btnEditar.setText("Editar");
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });

        btnExcluir.setFont(new java.awt.Font("Quicksand", 0, 15)); // NOI18N
        btnExcluir.setText("Excluir");
        btnExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirActionPerformed(evt);
            }
        });

        btnVoltar.setFont(new java.awt.Font("Quicksand", 0, 15)); // NOI18N
        btnVoltar.setText("Voltar");
        btnVoltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVoltarActionPerformed(evt);
            }
        });

        btnEmitirPdf.setFont(new java.awt.Font("Quicksand", 0, 15)); // NOI18N
        btnEmitirPdf.setText("Emitir PDF");
        btnEmitirPdf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEmitirPdfActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 553, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(38, 38, 38)
                                .addComponent(lblNome)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnBuscar))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(136, 136, 136)
                                .addComponent(lblTItulo)))
                        .addGap(0, 1, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addComponent(btnEditar)
                        .addGap(32, 32, 32)
                        .addComponent(btnExcluir)
                        .addGap(32, 32, 32)
                        .addComponent(btnEmitirPdf)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnVoltar)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(lblTItulo)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNome)
                    .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnExcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnVoltar, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(btnEmitirPdf, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addGap(43, 43, 43))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
     String termo = txtNome.getText().trim();
     carregarTabelaProntuarios(termo);
     
        // Lógica de busca no DAO por nome do animal ou ID
        JOptionPane.showMessageDialog(this, "Buscando prontuário por: " + termo);
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActionPerformed
        int linhaSelecionada = tblProntuario.getSelectedRow();
        if (linhaSelecionada == -1) {
        JOptionPane.showMessageDialog(this, "Por favor, selecione um prontuário na tabela para editar!");
        return;
        }
        
        Object idObj = tblProntuario.getValueAt(linhaSelecionada, 0);
        int idProntuario = Integer.parseInt(idObj.toString());
        
        CadastroProntuario telaEdicao = new CadastroProntuario(idProntuario);
        telaEdicao.setVisible(true);
       
        this.dispose();
        
    }//GEN-LAST:event_btnEditarActionPerformed

    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcluirActionPerformed
        int linhaSelecionada = tblProntuario.getSelectedRow();
        
        if (linhaSelecionada == -1) {
            JOptionPane.showMessageDialog(this, "Por favor, selecione um prontuário na tabela para excluir!");
            return;
        }

        int idProntuario = Integer.parseInt(tblProntuario.getValueAt(linhaSelecionada, 0).toString());
        String nomePaciente = tblProntuario.getValueAt(linhaSelecionada, 1).toString();

        int confirmacao = JOptionPane.showConfirmDialog(
            this, 
            "Tem certeza que deseja excluir o prontuário do paciente: " + nomePaciente + "?", 
            "Confirmação de Exclusão", 
            JOptionPane.YES_NO_OPTION
        );

        if (confirmacao == JOptionPane.YES_OPTION) {
            ProntuarioDAO dao = new ProntuarioDAO();
            boolean sucesso = dao.excluirProntuario(idProntuario);

            if (sucesso) {
                JOptionPane.showMessageDialog(this, "Prontuário excluído com sucesso!");
                carregarTabelaProntuarios(""); // Atualiza a tabela
            } else {
                JOptionPane.showMessageDialog(this, "Erro ao excluir o prontuário.");
            }
        }
    }//GEN-LAST:event_btnExcluirActionPerformed

    private void btnVoltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVoltarActionPerformed
        FormCadastrar menu = new FormCadastrar();
        menu.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnVoltarActionPerformed

    private void btnEmitirPdfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEmitirPdfActionPerformed
        int linhaSelecionada = tblProntuario.getSelectedRow();
        
        // Valida se o usuário selecionou uma linha na tabela
        if (linhaSelecionada == -1) {
            JOptionPane.showMessageDialog(this, "Por favor, selecione um prontuário na tabela para emitir o PDF!");
            return;
        }

        // Pega os dados das colunas da linha selecionada (ignorando o ID na coluna 0)
        String paciente = tblProntuario.getValueAt(linhaSelecionada, 1).toString();
        String enfermidade = tblProntuario.getValueAt(linhaSelecionada, 2).toString();
        String tratamento = tblProntuario.getValueAt(linhaSelecionada, 3).toString();
        String funcionario = tblProntuario.getValueAt(linhaSelecionada, 4).toString();
        String data = tblProntuario.getValueAt(linhaSelecionada, 5).toString();

        // Chama o gerador de PDF passando os dados reais do animal/prontuário escolhido
        GeradorPdf.gerarFichaProntuario(paciente, enfermidade, tratamento, funcionario, data);
    }//GEN-LAST:event_btnEmitirPdfActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ex) {
            java.util.logging.Logger.getLogger(ConsultaProntuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(() -> new ConsultaProntuario().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnEmitirPdf;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnVoltar;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblNome;
    private javax.swing.JLabel lblTItulo;
    private javax.swing.JTable tblProntuario;
    private javax.swing.JTextField txtNome;
    // End of variables declaration//GEN-END:variables
}
