package mucky.dao;

import mucky.Tratamento;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import mucky.Tratamento;

/**
 * @author deborah
 */
public class TratamentoDAO {
    private static final String URL = "jdbc:mariadb://localhost:3306/sistema_mucky?useSSL=false";
    private static final String USUARIO = "root";
    private static final String SENHA = "";

   
    public boolean cadastrarTipoTratamento(String nome, String descricao) {
        String sql = "INSERT INTO tipos_tratamento (nome, descricao) VALUES (?, ?)";

        try (Connection conn = DriverManager.getConnection(URL, USUARIO, SENHA);
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, nome);
            stmt.setString(2, descricao);
            stmt.executeUpdate();
            return true;

        } catch (SQLException e) {
            System.err.println("Erro ao cadastrar tipo de tratamento: " + e.getMessage());
            return false;
        }
    }

   
    public List<String> listarNomesTratamentos() {
        List<String> lista = new ArrayList<>();
        String sql = "SELECT nome FROM tipos_tratamento ORDER BY nome ASC";

        try (Connection conn = DriverManager.getConnection(URL, USUARIO, SENHA);
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                lista.add(rs.getString("nome"));
            }

        } catch (SQLException e) {
            System.err.println("Erro ao listar tratamentos: " + e.getMessage());
        }
        return lista;
    }

   
    public List<Tratamento> listarTratamentosCompletos() {
        List<Tratamento> lista = new ArrayList<>();
        String sql = "SELECT id, nome, descricao FROM tipos_tratamento ORDER BY id ASC";

        try (Connection conn = DriverManager.getConnection(URL, USUARIO, SENHA);
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Tratamento t = new Tratamento(
                    rs.getInt("id"),
                    rs.getString("nome"),
                    rs.getString("descricao")
                );
                lista.add(t);
            }

        } catch (SQLException e) {
            System.err.println("Erro ao listar tratamentos na tabela: " + e.getMessage());
        }
        return lista;
    }
}