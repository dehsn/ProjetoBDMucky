package mucky.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
/**
 *
 * @author deborah
 */
public class FuncionarioDAO {
    private static final String URL = "jdbc:mariadb://localhost:3306/sistema_mucky?useSSL=false";
    private static final String USUARIO = "root"; 
    private static final String SENHA = "";      

    public boolean cadastrarFuncionario(String nome, String cpf, String endereco, String cidade, 
                                        String telefone, String email, String funcao, String admissaoStr) {
        
        String sql = "INSERT INTO funcionarios (nome, cpf, endereco, cidade, telefone, email, funcao, admissao) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(URL, USUARIO, SENHA);
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, nome);
            stmt.setString(2, cpf);
            stmt.setString(3, endereco);
            stmt.setString(4, cidade);
            stmt.setString(5, telefone);
            stmt.setString(6, email);
            stmt.setString(7, funcao);
            
            // Tratamento e conversão da data do padrão brasileiro (DD/MM/AAAA) para o banco (AAAA-MM-DD)
            if (admissaoStr != null && !admissaoStr.trim().isEmpty()) {
                try {
                    // Define o formato brasileiro que o usuário vai digitar
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                    
                    // Faz o parse da String para LocalDate usando o formato do Brasil
                    LocalDate dataAdmissao = LocalDate.parse(admissaoStr, formatter);
                    
                    // Envia para o banco no formato aceito pelo SQL (java.sql.Date)
                    stmt.setDate(8, java.sql.Date.valueOf(dataAdmissao));
                    
                } catch (DateTimeParseException e) {
                    System.err.println("Erro: Formato de data inválido. Use DD/MM/AAAA.");
                    return false;
                }
            } else {
                stmt.setNull(8, java.sql.Types.DATE);
            }

            stmt.executeUpdate();
            return true;

        } catch (SQLException e) {
            System.err.println("Erro ao cadastrar funcionário: " + e.getMessage());
            return false;
        }
    }
}