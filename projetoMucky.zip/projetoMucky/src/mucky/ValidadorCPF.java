
package mucky;

/**
 *
 * @author deborah
 */
public class ValidadorCPF {
    public static boolean isCPFValido(String cpf) {
        if (cpf == null) {
            return false;
        }

        // Remove pontos, traços ou espaços deixados pela máscara
        cpf = cpf.replaceAll("[^0-9]", "");

        // Verifica tamanho e sequências inválidas conhecidas
        if (cpf.length() != 11 || cpf.matches("(\\d)\\1{10}")) {
            return false;
        }

        try {
            // Cálculo do 1º Dígito Verificador
            int soma = 0;
            int peso = 10;
            for (int i = 0; i < 9; i++) {
                int num = Character.getNumericValue(cpf.charAt(i));
                soma += (num * peso);
                peso--;
            }

            int resto = 11 - (soma % 11);
            char digito10 = (resto == 10 || resto == 11) ? '0' : (char) (resto + '0');

            // Cálculo do 2º Dígito Verificador
            soma = 0;
            peso = 11;
            for (int i = 0; i < 10; i++) {
                int num = Character.getNumericValue(cpf.charAt(i));
                soma += (num * peso);
                peso--;
            }

            resto = 11 - (soma % 11);
            char digito11 = (resto == 10 || resto == 11) ? '0' : (char) (resto + '0');

            // Confere se os dígitos calculados batem com os digitados
            return (digito10 == cpf.charAt(9)) && (digito11 == cpf.charAt(10));

        } catch (Exception e) {
            return false;
        }
    }
}
