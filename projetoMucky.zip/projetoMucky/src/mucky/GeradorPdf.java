package mucky;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.Desktop;
import java.io.File;
import java.io.FileOutputStream;
import javax.swing.JOptionPane;


public class GeradorPdf {
    public static void gerarFichaProntuario(String paciente, String enfermidade, String tratamento, String funcionario, String data) {
        Document documento = new Document();
        try {
            String nomeArquivo = "Ficha_Prontuario_" + paciente.replaceAll(" ", "_") + ".pdf";
            PdfWriter.getInstance(documento, new FileOutputStream(nomeArquivo));
            
            documento.open();
            
            Font fontTitulo = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD);
            Font fontTexto = new Font(Font.FontFamily.HELVETICA, 12, Font.NORMAL);
            Font fontNegrito = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD);
            
            Paragraph titulo = new Paragraph("Prontuário de Atendimento", fontTitulo);
            titulo.setAlignment(Paragraph.ALIGN_CENTER);
            documento.add(titulo);
            
            documento.add(new Paragraph(" "));
            documento.add(new Paragraph("------------------------------------------------------------------------------------------------------------------"));
            documento.add(new Paragraph(" "));
            
            documento.add(new Paragraph("Paciente: " + paciente, fontTexto));
            documento.add(new Paragraph("Enfermidade / Diagnóstico: " + enfermidade, fontTexto));
            documento.add(new Paragraph("Tratamento: " + tratamento, fontTexto));
            documento.add(new Paragraph("Profissional Responsável: " + funcionario, fontTexto));
            documento.add(new Paragraph("Data do Atendimento: " + data, fontTexto));
            
            documento.add(new Paragraph(" "));
            documento.add(new Paragraph(" "));
            documento.add(new Paragraph("____________________________________________________", fontTexto));
            documento.add(new Paragraph("Assinatura do Responsável", fontNegrito));
            
            documento.close();
            
          //abre o pdf após gerar
            File arquivoPdf = new File(nomeArquivo);
            if (arquivoPdf.exists()) {
                Desktop.getDesktop().open(arquivoPdf);
            }
            
            JOptionPane.showMessageDialog(null, "PDF gerado e aberto com sucesso!");
            
        } catch (DocumentException | java.io.IOException e) {
            JOptionPane.showMessageDialog(null, "Erro ao gerar PDF: " + e.getMessage());
        }
    }
}