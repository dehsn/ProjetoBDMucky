package mucky.dao;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

/**
 *
 * @author deborah
 */
public class AnimalDAO {

    private static final String URL = "jdbc:mariadb://localhost:3306/sistema_mucky?useSSL=false";
    private static final String USUARIO = "root";
    private static final String SENHA = "";

    public boolean cadastrarAnimal(String nome, String especie, String idadeAproximada,
            String sexo, String motivoResgate, String dataResgateStr) {

        String sql = "INSERT INTO animais (nome, especie, idade_aproximada, sexo, motivo_resgate, data_resgate) "
                + "VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(URL, USUARIO, SENHA);
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, nome);
            stmt.setString(2, especie);
            stmt.setString(3, idadeAproximada);
            stmt.setString(4, sexo);
            stmt.setString(5, motivoResgate);

            // Conversão de data do padrão brasileiro (dd/MM/yyyy) para SQL (yyyy-MM-dd)
            if (dataResgateStr != null && !dataResgateStr.trim().isEmpty()) {
                try {
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                    LocalDate dataResgate = LocalDate.parse(dataResgateStr, formatter);
                    stmt.setDate(6, java.sql.Date.valueOf(dataResgate));
                } catch (DateTimeParseException e) {
                    System.err.println("Erro: Formato de data inválido. Use DD/MM/AAAA.");
                    return false;
                }
            } else {
                stmt.setNull(6, java.sql.Types.DATE);
            }

            stmt.executeUpdate();
            return true;

        } catch (SQLException e) {
            System.err.println("Erro ao cadastrar animal: " + e.getMessage());
            return false;
        }
    }

    public boolean atualizarAnimal(int id, String nome, String especie, String idade, String sexo, String motivo, String dataResgate) {
        String sql = "UPDATE animais SET nome = ?, especie = ?, idade_aproximada = ?, sexo = ?, motivo_resgate = ?, data_resgate = ? WHERE id = ?";

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/sistema_mucky?useSSL=false", "root", "");
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, nome);
            stmt.setString(2, especie);
            stmt.setString(3, idade);
            stmt.setString(4, sexo);
            stmt.setString(5, motivo);
            stmt.setString(6, dataResgate);
            stmt.setInt(7, id);

            stmt.executeUpdate();
            return true;

        } catch (SQLException e) {
            System.out.println("Erro ao atualizar: " + e.getMessage());
            return false;
        }
    }
}
