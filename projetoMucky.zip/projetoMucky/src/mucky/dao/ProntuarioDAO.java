package mucky.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import mucky.Funcionario;
import mucky.Funcionario;
import mucky.Paciente;
import mucky.Paciente;

public class ProntuarioDAO {

    private static final String URL = "jdbc:mariadb://localhost:3306/sistema_mucky?useSSL=false";
    private static final String USUARIO = "root";
    private static final String SENHA = "";

    // ==========================================
    // 1. CLASSES DTO INTERNAS (Para evitar erros de símbolo)
    // ==========================================
    
    public static class ProntuarioDTO {
        private int id;
        private String nomePaciente;
        private String enfermidade;
        private String nomeTratamento;
        private String nomeFuncionario;
        private String dataAtendimento;

        public ProntuarioDTO(int id, String nomePaciente, String enfermidade, String nomeTratamento, String nomeFuncionario, String dataAtendimento) {
            this.id = id;
            this.nomePaciente = nomePaciente;
            this.enfermidade = enfermidade;
            this.nomeTratamento = nomeTratamento;
            this.nomeFuncionario = nomeFuncionario;
            this.dataAtendimento = dataAtendimento;
        }

        public int getId() { return id; }
        public String getNomePaciente() { return nomePaciente; }
        public String getEnfermidade() { return enfermidade; }
        public String getNomeTratamento() { return nomeTratamento; }
        public String getNomeFuncionario() { return nomeFuncionario; }
        public String getDataAtendimento() { return dataAtendimento; }
    }

    public static class ProntuarioEdicaoDTO {
        private int idProntuario;
        private int idPaciente;
        private String nomePaciente;
        private String nomeTratamento;
        private String nomeFuncionario;
        private String enfermidade;
        private String dataAtendimento;

        public int getIdProntuario() { return idProntuario; }
        public void setIdProntuario(int idProntuario) { this.idProntuario = idProntuario; }
        public int getIdPaciente() { return idPaciente; }
        public void setIdPaciente(int idPaciente) { this.idPaciente = idPaciente; }
        public String getNomePaciente() { return nomePaciente; }
        public void setNomePaciente(String nomePaciente) { this.nomePaciente = nomePaciente; }
        public String getNomeTratamento() { return nomeTratamento; }
        public void setNomeTratamento(String nomeTratamento) { this.nomeTratamento = nomeTratamento; }
        public String getNomeFuncionario() { return nomeFuncionario; }
        public void setNomeFuncionario(String nomeFuncionario) { this.nomeFuncionario = nomeFuncionario; }
        public String getEnfermidade() { return enfermidade; }
        public void setEnfermidade(String enfermidade) { this.enfermidade = enfermidade; }
        public String getDataAtendimento() { return dataAtendimento; }
        public void setDataAtendimento(String dataAtendimento) { this.dataAtendimento = dataAtendimento; }
    }

    // ==========================================
    // 2. MÉTODOS DE BUSCA E APOIO
    // ==========================================

    public Paciente buscarPacientePorNome(String nomeBusca) {
        String sql = "SELECT id, nome FROM animais WHERE nome LIKE ? LIMIT 1";

        try (Connection conn = DriverManager.getConnection(URL, USUARIO, SENHA);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, "%" + nomeBusca + "%");
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new Paciente(rs.getInt("id"), rs.getString("nome"));
                }
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar paciente: " + e.getMessage());
        }
        return null;
    }

    public List<Funcionario> listarFuncionarios() {
    List<Funcionario> lista = new ArrayList<>();
    String sql = "SELECT id, nome FROM funcionarios ORDER BY nome ASC";

    try (Connection conn = DriverManager.getConnection(URL, USUARIO, SENHA);
         PreparedStatement stmt = conn.prepareStatement(sql);
         ResultSet rs = stmt.executeQuery()) {

        while (rs.next()) {
            Funcionario f = new Funcionario(
                rs.getInt("id"),
                rs.getString("nome")
            );
            lista.add(f);
        }
    } catch (SQLException e) {
        System.err.println("Erro ao listar funcionários: " + e.getMessage());
    }
    return lista;
}

    public int buscarIdFuncionarioPorNome(String nomeFuncionario) {
        String sql = "SELECT id FROM funcionarios WHERE nome = ?";
        try (Connection conn = DriverManager.getConnection(URL, USUARIO, SENHA);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, nomeFuncionario);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("id");
                }
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar ID do funcionário: " + e.getMessage());
        }
        return -1;
    }

    public int buscarIdTratamentoPorNome(String nomeTratamento) {
        String sql = "SELECT id FROM tipos_tratamento WHERE nome = ? LIMIT 1";
        try (Connection conn = DriverManager.getConnection(URL, USUARIO, SENHA);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, nomeTratamento);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("id");
                }
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar ID do tratamento: " + e.getMessage());
        }
        return -1;
    }

    // ==========================================
    // 3. MÉTODOS CRUD (Salvar, Listar, Buscar por ID, Atualizar, Excluir)
    // ==========================================

    public boolean salvarProntuario(int idPaciente, int idTratamento, int idFuncionario, String enfermidade, String dataAtendimentoStr) {
        String sql = "INSERT INTO prontuario_atendimento (id_paciente, id_tratamento, id_funcionario, enfermidade, data_atendimento) "
                   + "VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(URL, USUARIO, SENHA);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idPaciente);
            stmt.setInt(2, idTratamento);
            stmt.setInt(3, idFuncionario);
            stmt.setString(4, enfermidade);

            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            LocalDate dataAtendimento = LocalDate.parse(dataAtendimentoStr, formatter);
            stmt.setDate(5, java.sql.Date.valueOf(dataAtendimento));

            stmt.executeUpdate();
            return true;

        } catch (Exception e) {
            System.err.println("Erro ao salvar prontuário: " + e.getMessage());
            return false;
        }
    }

    public List<ProntuarioDTO> listarProntuarios(String filtroNome) {
        List<ProntuarioDTO> lista = new ArrayList();
        
        StringBuilder sql = new StringBuilder(
            "SELECT p.id_prontuario AS id, a.nome AS paciente, p.enfermidade, t.nome AS tratamento, f.nome AS funcionario, p.data_atendimento " +
            "FROM prontuario_atendimento p " +
            "JOIN animais a ON p.id_paciente = a.id " +
            "JOIN tipos_tratamento t ON p.id_tratamento = t.id " +
            "JOIN funcionarios f ON p.id_funcionario = f.id "
        );

        if (filtroNome != null && !filtroNome.trim().isEmpty()) {
            sql.append("WHERE a.nome LIKE ? ");
        }
        
        sql.append("ORDER BY p.data_atendimento DESC");

        try (Connection conn = DriverManager.getConnection(URL, USUARIO, SENHA);
             PreparedStatement stmt = conn.prepareStatement(sql.toString())) {

            if (filtroNome != null && !filtroNome.trim().isEmpty()) {
                stmt.setString(1, "%" + filtroNome + "%");
            }

            try (ResultSet rs = stmt.executeQuery()) {
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                
                while (rs.next()) {
                    java.sql.Date dataSql = rs.getDate("data_atendimento");
                    String dataFormatada = "";
                    if (dataSql != null) {
                        dataFormatada = dataSql.toLocalDate().format(formatter);
                    }

                    ProntuarioDTO dto = new ProntuarioDTO(
                        rs.getInt("id"),
                        rs.getString("paciente"),
                        rs.getString("enfermidade"),
                        rs.getString("tratamento"),
                        rs.getString("funcionario"),
                        dataFormatada
                    );
                    lista.add(dto);
                }
            }
        } catch (SQLException e) {
            System.err.println("Erro ao listar prontuários: " + e.getMessage());
        }
        return lista;
    }

    public ProntuarioEdicaoDTO buscarProntuarioPorId(int idProntuario) {
        String sql = "SELECT p.id_prontuario, p.id_paciente, a.nome AS paciente, " +
                     "t.nome AS tratamento, f.nome AS funcionario, " +
                     "p.enfermidade, p.data_atendimento " +
                     "FROM prontuario_atendimento p " +
                     "JOIN animais a ON p.id_paciente = a.id " +
                     "JOIN tipos_tratamento t ON p.id_tratamento = t.id " +
                     "JOIN funcionarios f ON p.id_funcionario = f.id " +
                     "WHERE p.id_prontuario = ?";

        try (Connection conn = DriverManager.getConnection(URL, USUARIO, SENHA);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idProntuario);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    ProntuarioEdicaoDTO dto = new ProntuarioEdicaoDTO();
                    dto.setIdProntuario(rs.getInt("id_prontuario"));
                    dto.setIdPaciente(rs.getInt("id_paciente"));
                    dto.setNomePaciente(rs.getString("paciente"));
                    dto.setNomeTratamento(rs.getString("tratamento"));
                    dto.setNomeFuncionario(rs.getString("funcionario"));
                    dto.setEnfermidade(rs.getString("enfermidade"));
                    
                    java.sql.Date dataSql = rs.getDate("data_atendimento");
                    if (dataSql != null) {
                        dto.setDataAtendimento(dataSql.toLocalDate().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
                    }
                    return dto;
                }
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar prontuário por ID: " + e.getMessage());
        }
        return null;
    }

    public boolean atualizarProntuario(int idProntuario, int idPaciente, int idTratamento, int idFuncionario, String enfermidade, String dataAtendimentoStr) {
        String sql = "UPDATE prontuario_atendimento SET id_paciente = ?, id_tratamento = ?, id_funcionario = ?, enfermidade = ?, data_atendimento = ? " +
                     "WHERE id_prontuario = ?";

        try (Connection conn = DriverManager.getConnection(URL, USUARIO, SENHA);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idPaciente);
            stmt.setInt(2, idTratamento);
            stmt.setInt(3, idFuncionario);
            stmt.setString(4, enfermidade);

            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            LocalDate dataAtendimento = LocalDate.parse(dataAtendimentoStr, formatter);
            stmt.setDate(5, java.sql.Date.valueOf(dataAtendimento));
            stmt.setInt(6, idProntuario);

            stmt.executeUpdate();
            return true;

        } catch (Exception e) {
            System.err.println("Erro ao atualizar prontuário: " + e.getMessage());
            return false;
        }
    }

    public boolean excluirProntuario(int idProntuario) {
        String sql = "DELETE FROM prontuario_atendimento WHERE id_prontuario = ?";

        try (Connection conn = DriverManager.getConnection(URL, USUARIO, SENHA);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idProntuario);
            int linhasAfetadas = stmt.executeUpdate();
            return linhasAfetadas > 0;

        } catch (SQLException e) {
            System.err.println("Erro ao excluir prontuário: " + e.getMessage());
            return false;
        }
    }
}